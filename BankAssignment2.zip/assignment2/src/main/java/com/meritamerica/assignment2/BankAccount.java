package com.meritamerica.assignment2;

public class BankAccount {
	private double bal;
	private double iRate;
	private long accNumber;
	
	BankAccount(double balance, double interestRate) {
		this.bal=balance;
		this.iRate=interestRate;
	}
	BankAccount(long accountNumber, double balance, double interestRate) {
		this.accNumber=accountNumber;
		this.bal=balance;
		this.iRate=interestRate;
	}
	public long getAccountNumber() {
		return accNumber;
	}
	public double getBalance() {
		return bal;
	}
	public double getInterestRate() {
		return iRate;
	}
	public boolean withdraw(double amount) {
		if(amount < 0)
			return false;
		if(bal-amount <0)
			return false;
		else {
			bal=bal-amount;
			return true;
		}
	}
	boolean deposit (double amount) {
		if(amount < 0)
			return false;
		else {
			bal=bal+amount;
			return true;
		}
	}
	double futureValue(int years) {
		 return  bal * (Math.pow(1+iRate, years));

	}


}

