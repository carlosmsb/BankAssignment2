package com.meritamerica.assignment2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Random;
import java.util.TreeMap;

public class MeritBank {
	
	static long MbAccNumber = 1000;
	
	static ArrayList <AccountHolder> accHolderArr = new ArrayList<AccountHolder>();
	static ArrayList <CDOffering> offeringArray = new ArrayList<CDOffering>();
	static ArrayList<Double> arr = new ArrayList<Double>();
	
	static void addAccountHolder(AccountHolder accountHolder) {
		accHolderArr.add(accountHolder);
	}
	static AccountHolder[] getAccountHolders() {
		return (AccountHolder[])accHolderArr.toArray();
	}
	static CDOffering[] getCDOfferings() {
		return (CDOffering[])offeringArray.toArray();
	}
	static CDOffering getBestCDOffering (double depositAmount) {
		int t=0;
		double iRate=0.00;
		double fv=0.00;
		HashMap<Double, CDOffering> hm = new HashMap<>();
		for(int i = 0; i<offeringArray.size(); i++) {
			t=offeringArray.get(i).getTerm();
			iRate=offeringArray.get(i).getInterestRate();
			fv=futureValue(depositAmount, iRate, t);
		}
		TreeMap<Double, CDOffering> tmap = new TreeMap<>();
		return tmap.lastEntry().getValue();
	}
	static CDOffering getSecondBestCDOffering (double depositAmount) {
		int t=0;
		double iRate=0.00;
		double fv=0.00;
			HashMap<Double, CDOffering> hm = new HashMap<>();
			for(int i = 0; i<offeringArray.size(); i++) {
				t=offeringArray.get(i).getTerm();
				iRate=offeringArray.get(i).getInterestRate();
				fv=futureValue(depositAmount, iRate, t);
			}
			TreeMap<Double, CDOffering> tmap = new TreeMap<>();
			
			int ind=tmap.size() - 2;
			return tmap.get((double)ind);
	}

	static void clearCDOfferings() {
		offeringArray.clear();
	}
	static void setCDOfferings(CDOffering[] offerings) {
		offeringArray.clear();
		if (offerings != null) {
			for(int i = 0; i<offeringArray.size(); i++) {
				offeringArray.add(offerings[i]);
			}
		}
	}

	static long getNextAccountNumber() {
		return MbAccNumber = MbAccNumber + 1;
	}
	static double totalBalances() {
		double totalBalance = 0.00;
		for(int i = 0; i<accHolderArr.size(); i++) {
			totalBalance = totalBalance + (accHolderArr.get(i).getCombinedBalance());
		}
		return totalBalance;
	}
	static double futureValue(double presentValue, double interestRate, int term) {
			 return presentValue * (Math.pow(1+interestRate, term));
	}

}
