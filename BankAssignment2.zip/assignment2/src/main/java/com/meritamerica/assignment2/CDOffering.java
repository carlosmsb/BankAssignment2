package com.meritamerica.assignment2;

public class CDOffering {
	private int t;
	private double i;
	
	CDOffering(int term, double interestRate) {
		this.t=term;
		this.i=interestRate;
	}
	
public int getTerm() {
	return t;
}

public double getInterestRate() {
	return i;
}

}


