package com.meritamerica.assignment2;

public class CheckingAccount extends BankAccount {
	CheckingAccount(long accNumber, double openingBalance) {
	
	super(accNumber, openingBalance, 0.0001);
	}
}