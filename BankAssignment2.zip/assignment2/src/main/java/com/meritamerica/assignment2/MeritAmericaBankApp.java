package com.meritamerica.assignment2;

public class MeritAmericaBankApp {
	public static void main(String[] args) {
		CDOffering cd;
		CDOffering[] offerings = new CDOffering[5];
		cd = new CDOffering (1, 0.0018);
		offerings[0] = cd;
		offerings[1] = new CDOffering(2, 0.0019);
		offerings[2] = new CDOffering(3, 0.002);
		offerings[3] = new CDOffering(5, 0.0025);
		offerings[4] = new CDOffering(10, 0.0022);
		MeritBank.setCDOfferings(offerings);
		
		System.out.println("set CDoffering");
		
		AccountHolder ah1 = new AccountHolder ("John", "Doe", "James", "123-456");
		System.out.println("hello john");
		
		if(ah1.getCheckingBalance() + ah1.getSavingsBalance() <250000) {
			
		
		
		ah1.addCheckingAccount(1000);
		ah1.addSavingsAccount(10000);
		}
		ah1.addCheckingAccount(5000);
		ah1.addSavingsAccount(50000);
		
		ah1.addCheckingAccount(50000);
		ah1.addSavingsAccount(500000);
		
		ah1.addCheckingAccount(5000);
		ah1.addSavingsAccount(50000);
		
		System.out.println("created account");
	
	//CDOffering offer = MeritBank.getBestCDOffering(1000.00);
	//ah1.addCDAccount(offer, 1000.00);
	//MeritBank.addAccountHolder(ah1);
	
	System.out.println("best offer " + ah1.toString());
	
	MeritBank.addAccountHolder(ah1);
	
	AccountHolder ah2 = new AccountHolder ("Abcd", "Doe", "LastName", "000-999");
	
	if(ah2.getCheckingBalance() + ah1.getSavingsBalance() <250000) {
			
		
		
		ah2.addCheckingAccount(1000);
		ah2.addSavingsAccount(10000);
		
		MeritBank.clearCDOfferings();
	//	CDOffering offer = MeritBank.getBestCDOffering(1000.00);
	//  ah2.addCDAccount(offer, 1000.00);
	//	MeritBank.addAccountHolder(ah2);
		
		System.out.println("testing");
		
		MeritBank.addAccountHolder(ah2);
		MeritBank.clearCDOfferings();
		
	
		AccountHolder ah3 = new AccountHolder ("Don", "Eddie", "Trump", "111-222");
		if(ah3.getCheckingBalance() + ah3.getSavingsBalance() <250000) {
			
		ah3.addCDAccount(null);
		
		ah3.addCheckingAccount(1000);
		ah3.addSavingsAccount(10000);
		
		MeritBank.addAccountHolder(ah3);
		System.out.println("testing test" + MeritBank.totalBalances());
	}
	
	}
	}
}