package com.meritamerica.assignment2;

import java.time.LocalDate;
import java.util.Date;

public class CDAccount {
	private CDOffering offer;
	private double bal;
	
	CDAccount(CDOffering offering, double balance) {
	 this.offer=offering;
	 this.bal=balance;
	}

	public double getBalance() {
		return bal;
	}
	public double getInterestRate() {
		return offer.getInterestRate();
	}
	
	public int getTerm() {
		return offer.getTerm();
	}
	public LocalDate getStartDate() {
		return LocalDate.now();
	}
	public long getAccountNumber() {
		return getAccountNumber();
	}
	
	double futureValue(int years) {
		 return  bal * (Math.pow(1+getInterestRate(), years));

	}

}



