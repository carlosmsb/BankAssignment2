package com.meritamerica.assignment2;

public class SavingsAccount extends BankAccount {
	SavingsAccount(long accNumber, double openingBalance) {
		
		super(accNumber, openingBalance, 0.0001);
		}

}